# Dead Streets

A small original top-down zombie survival browser game inspired by the survival genre.

## Run locally
Open `index.html` in a browser.

## GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html`, `style.css`, and `game.js`.
3. Open Settings -> Pages.
4. Select the main branch and root folder.
5. Save and open the generated Pages URL.

## Controls
- WASD / Arrow keys: move
- Mouse: aim
- Left click: shoot
- E: loot nearby crate
- R: restart after death
