const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");

const W = canvas.width;
const H = canvas.height;

const keys = {};
const mouse = { x: W / 2, y: H / 2, down: false };

let player, zombies, bullets, crates, kills, gameOver, lastTime;
let spawnTimer = 0;
let hungerTimer = 0;
let shootCooldown = 0;

const world = {
  width: 2400,
  height: 1600,
  cameraX: 0,
  cameraY: 0
};

function resetGame() {
  player = {
    x: world.width / 2,
    y: world.height / 2,
    speed: 210,
    health: 100,
    hunger: 100,
    ammo: 12,
    radius: 13
  };

  zombies = [];
  bullets = [];
  crates = [];
  kills = 0;
  gameOver = false;
  spawnTimer = 0;
  hungerTimer = 0;
  shootCooldown = 0;

  for (let i = 0; i < 30; i++) {
    crates.push({
      x: 150 + Math.random() * (world.width - 300),
      y: 150 + Math.random() * (world.height - 300),
      opened: false
    });
  }

  for (let i = 0; i < 14; i++) spawnZombie(true);

  document.getElementById("game-over").style.display = "none";
  updateHud();
}

function spawnZombie(initial = false) {
  let x, y;
  const angle = Math.random() * Math.PI * 2;
  const dist = initial ? 350 + Math.random() * 600 : 650 + Math.random() * 300;
  x = player.x + Math.cos(angle) * dist;
  y = player.y + Math.sin(angle) * dist;

  x = Math.max(30, Math.min(world.width - 30, x));
  y = Math.max(30, Math.min(world.height - 30, y));

  zombies.push({
    x, y,
    speed: 45 + Math.random() * 25,
    health: 40,
    radius: 14
  });
}

function updateHud() {
  document.getElementById("health").textContent = Math.max(0, Math.round(player.health));
  document.getElementById("hunger").textContent = Math.max(0, Math.round(player.hunger));
  document.getElementById("ammo").textContent = player.ammo;
  document.getElementById("kills").textContent = kills;
}

function shoot() {
  if (gameOver || shootCooldown > 0 || player.ammo <= 0) return;

  const wx = mouse.x + world.cameraX;
  const wy = mouse.y + world.cameraY;
  const dx = wx - player.x;
  const dy = wy - player.y;
  const len = Math.hypot(dx, dy) || 1;

  bullets.push({
    x: player.x,
    y: player.y,
    vx: dx / len * 650,
    vy: dy / len * 650,
    life: 0.9
  });

  player.ammo--;
  shootCooldown = 0.22;
}

function loot() {
  for (const crate of crates) {
    if (crate.opened) continue;
    const d = Math.hypot(crate.x - player.x, crate.y - player.y);
    if (d < 55) {
      crate.opened = true;
      if (Math.random() < 0.7) {
        player.ammo += 6 + Math.floor(Math.random() * 7);
      }
      if (Math.random() < 0.5) {
        player.hunger = Math.min(100, player.hunger + 20);
      }
      return;
    }
  }
}

function update(dt) {
  if (gameOver) return;

  shootCooldown = Math.max(0, shootCooldown - dt);

  let mx = 0, my = 0;
  if (keys["w"] || keys["ArrowUp"]) my--;
  if (keys["s"] || keys["ArrowDown"]) my++;
  if (keys["a"] || keys["ArrowLeft"]) mx--;
  if (keys["d"] || keys["ArrowRight"]) mx++;

  if (mx || my) {
    const len = Math.hypot(mx, my);
    mx /= len; my /= len;
    player.x += mx * player.speed * dt;
    player.y += my * player.speed * dt;
  }

  player.x = Math.max(20, Math.min(world.width - 20, player.x));
  player.y = Math.max(20, Math.min(world.height - 20, player.y));

  hungerTimer += dt;
  if (hungerTimer >= 2) {
    hungerTimer = 0;
    player.hunger = Math.max(0, player.hunger - 1);
    if (player.hunger <= 0) player.health -= 1;
  }

  for (const zombie of zombies) {
    const dx = player.x - zombie.x;
    const dy = player.y - zombie.y;
    const d = Math.hypot(dx, dy) || 1;

    zombie.x += dx / d * zombie.speed * dt;
    zombie.y += dy / d * zombie.speed * dt;

    if (d < zombie.radius + player.radius + 3) {
      player.health -= 12 * dt;
    }
  }

  for (const bullet of bullets) {
    bullet.x += bullet.vx * dt;
    bullet.y += bullet.vy * dt;
    bullet.life -= dt;

    for (const zombie of zombies) {
      if (zombie.health <= 0) continue;
      if (Math.hypot(bullet.x - zombie.x, bullet.y - zombie.y) < zombie.radius + 4) {
        zombie.health = 0;
        bullet.life = 0;
        kills++;
        break;
      }
    }
  }

  bullets = bullets.filter(b => b.life > 0);
  zombies = zombies.filter(z => z.health > 0);

  spawnTimer += dt;
  if (spawnTimer > 2.7) {
    spawnTimer = 0;
    if (zombies.length < 45) spawnZombie();
  }

  world.cameraX = Math.max(0, Math.min(world.width - W, player.x - W / 2));
  world.cameraY = Math.max(0, Math.min(world.height - H, player.y - H / 2));

  if (mouse.down) shoot();

  if (player.health <= 0) {
    player.health = 0;
    gameOver = true;
    document.getElementById("game-over").style.display = "flex";
  }

  updateHud();
}

function drawWorld() {
  ctx.fillStyle = "#303030";
  ctx.fillRect(0, 0, W, H);

  const grid = 80;
  ctx.strokeStyle = "#3a3a3a";
  ctx.lineWidth = 1;

  for (let x = -world.cameraX % grid; x < W; x += grid) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, H);
    ctx.stroke();
  }

  for (let y = -world.cameraY % grid; y < H; y += grid) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(W, y);
    ctx.stroke();
  }

  // Simple buildings
  for (let bx = 100; bx < world.width; bx += 400) {
    for (let by = 100; by < world.height; by += 350) {
      const sx = bx - world.cameraX;
      const sy = by - world.cameraY;
      if (sx > W || sy > H || sx + 220 < 0 || sy + 170 < 0) continue;

      ctx.fillStyle = "#454545";
      ctx.fillRect(sx, sy, 220, 170);

      ctx.strokeStyle = "#666";
      ctx.strokeRect(sx, sy, 220, 170);

      ctx.fillStyle = "#6d6d55";
      for (let wx = 20; wx < 200; wx += 55) {
        ctx.fillRect(sx + wx, sy + 25, 30, 30);
        ctx.fillRect(sx + wx, sy + 80, 30, 30);
      }
    }
  }
}

function draw() {
  ctx.clearRect(0, 0, W, H);
  drawWorld();

  for (const crate of crates) {
    const sx = crate.x - world.cameraX;
    const sy = crate.y - world.cameraY;
    if (sx < -30 || sy < -30 || sx > W + 30 || sy > H + 30) continue;

    ctx.fillStyle = crate.opened ? "#555" : "#a8793d";
    ctx.fillRect(sx - 12, sy - 12, 24, 24);
    ctx.strokeStyle = "#1f1f1f";
    ctx.strokeRect(sx - 12, sy - 12, 24, 24);
  }

  for (const bullet of bullets) {
    ctx.fillStyle = "#ffd36b";
    ctx.beginPath();
    ctx.arc(bullet.x - world.cameraX, bullet.y - world.cameraY, 3, 0, Math.PI * 2);
    ctx.fill();
  }

  for (const zombie of zombies) {
    const sx = zombie.x - world.cameraX;
    const sy = zombie.y - world.cameraY;

    ctx.fillStyle = "#78906f";
    ctx.beginPath();
    ctx.arc(sx, sy, zombie.radius, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = "#222";
    ctx.fillRect(sx - 7, sy - 4, 4, 4);
    ctx.fillRect(sx + 3, sy - 4, 4, 4);
  }

  // Player
  const px = player.x - world.cameraX;
  const py = player.y - world.cameraY;

  ctx.fillStyle = "#d9d9d9";
  ctx.beginPath();
  ctx.arc(px, py, player.radius, 0, Math.PI * 2);
  ctx.fill();

  const ax = mouse.x;
  const ay = mouse.y;
  const adx = ax - px;
  const ady = ay - py;
  const alen = Math.hypot(adx, ady) || 1;

  ctx.strokeStyle = "#ddd";
  ctx.lineWidth = 5;
  ctx.beginPath();
  ctx.moveTo(px, py);
  ctx.lineTo(px + adx / alen * 23, py + ady / alen * 23);
  ctx.stroke();
}

function loop(timestamp) {
  const dt = Math.min(0.033, (timestamp - lastTime) / 1000 || 0);
  lastTime = timestamp;

  update(dt);
  draw();
  requestAnimationFrame(loop);
}

window.addEventListener("keydown", e => {
  keys[e.key] = true;
  if (e.key.toLowerCase() === "e") loot();
  if (e.key.toLowerCase() === "r" && gameOver) resetGame();
});

window.addEventListener("keyup", e => keys[e.key] = false);

canvas.addEventListener("mousemove", e => {
  const rect = canvas.getBoundingClientRect();
  mouse.x = (e.clientX - rect.left) * W / rect.width;
  mouse.y = (e.clientY - rect.top) * H / rect.height;
});

canvas.addEventListener("mousedown", () => {
  mouse.down = true;
  shoot();
});

window.addEventListener("mouseup", () => mouse.down = false);
window.addEventListener("blur", () => mouse.down = false);

resetGame();
requestAnimationFrame(loop);
